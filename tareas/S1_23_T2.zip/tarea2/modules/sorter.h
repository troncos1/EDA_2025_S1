#ifndef SORTER_H
#define SORTER_H

#include "processor.h"

void quicksort(CityData *cities, int low, int high);

#endif